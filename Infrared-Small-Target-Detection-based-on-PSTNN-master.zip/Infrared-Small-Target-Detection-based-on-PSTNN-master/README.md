# Infrared-Small-Target-Detection-based-on-PSTNN
This matlab code implements the infrared small target detection model based on partial sum of the tensor nuclear norm. Detailed description about this method can be found in our paper.

Reference:

    Zhang, L.; Peng, Z. Infrared Small Target Detection Based on Partial Sum of the Tensor Nuclear Norm. Remote Sens. 2019, 11, 382.
