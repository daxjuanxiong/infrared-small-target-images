# NRAM
The implemention of NRAM model in this paper:

Reference:
   Zhang L, Peng L, Zhang T, et al. Infrared Small Target Detection via Non-Convex 
   Rank Approximation Minimization Joint l2, 1 Norm[J]. Remote Sensing, 2018, 10(11): 1821.
   
For the detailed algorithm interpretation, please read our paper.
