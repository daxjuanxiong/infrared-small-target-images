function si = inci(x)
%function for incrementing the number to change the background image
if x==5
    si=1;
else
    si=x+1;
end